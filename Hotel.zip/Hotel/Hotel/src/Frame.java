import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//This is the frame which display the check-in process to the user
//The user interacts with this frame to complete the check-in
public class Frame implements ActionListener{
	
	private static SimpleDateFormat f = new SimpleDateFormat("MM/dd/yyyy");
	private static Calendar c = Calendar.getInstance();
	private static final Date startupDate = c.getTime();
	private Date curDate = startupDate;
	
	private ImageIcon hotelIcon = new ImageIcon(getClass().getClassLoader().getResource("Hotel-icon.png"));
	
	private Room inBookingProcess;
	private int bookingProcessRow;
	private int bookingProcessCol;
	
	private RoomStorage storage = new RoomStorage();
	private Room[][] arr = storage.getRoomList();
	private RoomBoardDisplay[][] roomPanel = new RoomBoardDisplay[6][8];
	private ArrayList<Room> yourBookedRooms = new ArrayList<Room>();
	
	private JFrame frame;
	private JLabel img;
	private JButton button;
	
	private JFrame instruFrame;
	private JTextArea instruArea;
	private JScrollPane instruScroll;
	
	private JFrame roomFrame;
	
	private JPanel step1;
	private JPanel step2;
	private JPanel step3;
	private JPanel step4;
	private JPanel step5;
	private JLabel step1Label;
	private JLabel step2Label;
	private JLabel step3Label;
	private JLabel step4Label;
	private JLabel step5Label;
	
	private JLabel c1;
	private JLabel c2;
	private JLabel c3;
	private JButton b1;
	private JButton b2;
	
	private JComboBox monthBoxStart;
	private JComboBox dayBoxStart;
	private JComboBox yearBoxStart;
	private JComboBox monthBoxEnd;
	private JComboBox dayBoxEnd;
	private JComboBox yearBoxEnd;
	private String[] months = {"MM", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	private String[] days31 = {"DD", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};
	private String[] days30 = {"DD", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"};
	private String[] days28 = {"DD", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28"};
	private String[] years = {"YYYY", "2021", "2022"};
	private int monthStart = -1;
	private int dayStart = -1;
	private int yearStart = -1;
	private int monthEnd = -1;
	private int dayEnd = -1;
	private int yearEnd = -1;
	private Date bookingStart;
	private Date bookingEnd;
	private boolean datesValid = false;
	private JLabel aboveLabel;
	private JLabel untilLabel;
	private JLabel validityLabel;
	private JButton checkOutButton;
	
	private JLabel usdLabel;
	private JLabel riCoinLabel;
	private JButton usdPayButton;
	private JButton riCoinPayButton;
	private JLabel conversionLabel;
	
	private JLabel congratulationsLabel1;
	private JLabel congratulationsLabel2;
	private JButton bookNewRoom;
	private JLabel yourRoomsBookedLabel;
	private JButton showYourRooms;
	
	private JFrame roomsBookedFrame;
	private JTextArea roomListArea;
	
	//Creates the panel of rooms and the frame
	public Frame() {
		setRoomPanel();
		StartFrame();
	}
	
	//Creates the initial frame, label, and button used to begin
	public void StartFrame() {
		
		ImageIcon home = new ImageIcon(getClass().getClassLoader().getResource("RicoHome1080540.png"));
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1096, 578);
		frame.setTitle("Welcome to Rico Hotels");
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setLayout(null);
		frame.setIconImage(hotelIcon.getImage());
		
		button = new JButton();
		button.setBounds(390, 480, 300, 50);
		button.setForeground(Color.white);
		button.setFont(new Font("Candara", Font.PLAIN, 24));
		button.setText("Enter The Experience");
		button.setOpaque(false);
		button.setContentAreaFilled(false);
		button.setBorderPainted(false);
		button.addActionListener(this);
		frame.add(button);
		
		img = new JLabel();
		img.setBounds(0, 0, 1080, 540);
		img.setIcon(home);
		frame.add(img);
	}
	
	//Displays the roomPanel, taking information from the RoomStorage class and displaying it on the frame
	public void showRoomBoard() {
		int height = 330;
		int width = 100;
		Room[][] arr = storage.getRoomList();
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[0].length; j++) {
				roomFrame.add(roomPanel[i][j].getJP());
				roomPanel[i][j].getJP().add(roomPanel[i][j].getJL());
				roomPanel[i][j].setRoomNumber(arr[i][j].getRoomNumber());
				roomPanel[i][j].getJP().setBounds(height, width, 50, 50);
				roomPanel[i][j].getJB().setBounds(height, width, 50, 50);
				roomPanel[i][j].getJB().setOpaque(false);
				roomPanel[i][j].getJB().setContentAreaFilled(false);
				roomPanel[i][j].getJB().setBorderPainted(false);
				if(roomPanel[i][j].getJB() != null) {
					roomFrame.add(roomPanel[i][j].getJB());
				}
				width += 60;
				if(arr[i][j].getIsBooked()) {
					roomPanel[i][j].getJP().setBackground(Color.red);
				}
				else if(arr[i][j].getRoomClass().equals("Standard")){ //bronze
					roomPanel[i][j].getJP().setBackground(new Color(0xCD7F32));
				}
				else if(arr[i][j].getRoomClass().equals("Premium")){ //silver
					roomPanel[i][j].getJP().setBackground(new Color(0xC0C0C0));
				}
				else if(arr[i][j].getRoomClass().equals("Presidential")){ //gold
					roomPanel[i][j].getJP().setBackground(new Color(0xFFD700));
				}
				roomPanel[i][j].getJL().setText("" + arr[i][j].getRoomNumber());
			}
			height += 60;
			width = 100;
		}
	}
	
	//Creates the main room frame, including the starting menu and panels to display the steps of the check-in process
	public void DisplayRooms(){
		roomFrame = new JFrame();
		roomFrame.setSize(708, 708);
		roomFrame.setTitle("Room Availability");
		roomFrame.setResizable(false);
		roomFrame.setLayout(null);
		roomFrame.getContentPane().setBackground(new Color(0x4287f5));
		roomFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		roomFrame.setIconImage(hotelIcon.getImage());
		
		step1 = new JPanel();
		step1.setBounds(10, 40, 300, 100);
		step1.setBackground(Color.gray);
		roomFrame.add(step1);
		step1Label = new JLabel();
		step1Label.setPreferredSize(new Dimension(300, 100));
		step1Label.setFont(new Font("Candara", Font.PLAIN, 24));
		step1Label.setVerticalAlignment(JLabel.CENTER);
		step1Label.setHorizontalAlignment(JLabel.LEFT);
		step1Label.setText(" How to Check In");
		step1.add(step1Label);
		
		step2 = new JPanel();
		step2.setBounds(10, 160, 300, 100);
		step2.setBackground(Color.white);
		roomFrame.add(step2);
		step2Label = new JLabel();
		step2Label.setLayout(null);
		step2Label.setPreferredSize(new Dimension(300, 100));
		step2Label.setFont(new Font("Candara", Font.PLAIN, 24));
		step2Label.setVerticalAlignment(JLabel.CENTER);
		step2Label.setHorizontalAlignment(JLabel.LEFT);
		step2Label.setText(" Choose A Room");
		step2.add(step2Label);
		
		step3 = new JPanel();
		step3.setBounds(10, 280, 300, 100);
		step3.setBackground(Color.white);
		roomFrame.add(step3);
		step3Label = new JLabel();
		step3Label.setLayout(null);
		step3Label.setPreferredSize(new Dimension(300, 100));
		step3Label.setFont(new Font("Candara", Font.PLAIN, 24));
		step3Label.setVerticalAlignment(JLabel.CENTER);
		step3Label.setHorizontalAlignment(JLabel.LEFT);
		step3Label.setText(" Choose Dates");
		roomFrame.add(step3Label);
		step3.add(step3Label);
		
		step4 = new JPanel();
		step4.setBounds(10, 400, 300, 100);
		step4.setBackground(Color.white);
		roomFrame.add(step4);
		step4Label = new JLabel();
		step4Label.setLayout(null);
		step4Label.setPreferredSize(new Dimension(300, 100));
		step4Label.setFont(new Font("Candara", Font.PLAIN, 24));
		step4Label.setVerticalAlignment(JLabel.CENTER);
		step4Label.setHorizontalAlignment(JLabel.LEFT);
		step4Label.setText(" Checkout");
		step4.add(step4Label);
		
		step5 = new JPanel();
		step5.setBounds(10, 520, 300, 100);
		step5.setBackground(Color.white);
		roomFrame.add(step5);
		step5Label = new JLabel();
		step5Label.setLayout(null);
		step5Label.setPreferredSize(new Dimension(300, 100));
		step5Label.setFont(new Font("Candara", Font.PLAIN, 24));
		step5Label.setVerticalAlignment(JLabel.CENTER);
		step5Label.setHorizontalAlignment(JLabel.LEFT);
		step5Label.setText(" End");
		step5.add(step5Label);
		
		checkInInstructions();
		
		roomFrame.setVisible(true);
	}
	
	//Displays check in instructions when a user clicks to view them
	public void checkInInstructions() {
		c1 = new JLabel();
		c1.setBounds(310, 100, 388, 40);
		c1.setFont(new Font("Candara", Font.PLAIN, 24));
		c1.setHorizontalAlignment(JLabel.CENTER);
		c1.setText("Read the Check-In Guide below");
		roomFrame.add(c1);
		
		c2 = new JLabel();
		c2.setBounds(310, 140, 388, 40);
		c2.setFont(new Font("Candara", Font.PLAIN, 24));
		c2.setHorizontalAlignment(JLabel.CENTER);
		c2.setText("to view Check-In procedures");
		roomFrame.add(c2);
		
		b2 = new JButton();
		b2.setBounds(444, 200, 120, 40);
		b2.addActionListener(this);
		b2.setText("Guide");
		roomFrame.add(b2);
		
		c3 = new JLabel();
		c3.setBounds(310, 340, 388, 40);
		c3.setFont(new Font("Candara", Font.PLAIN, 24));
		c3.setHorizontalAlignment(JLabel.CENTER);
		c3.setText("Or Check In Here");
		roomFrame.add(c3);
		
		b1 = new JButton();
		b1.setBounds(444, 400, 120, 40);
		b1.addActionListener(this);
		b1.setText("Check-In");
		roomFrame.add(b1);
	}
	
	//Creates comboBoxes and labels to allow users to choose what days they would like to begin and end their stay
	public void chooseDates() {	
		aboveLabel = new JLabel();
		aboveLabel.setBounds(310, 160, 388, 40);
		aboveLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		aboveLabel.setHorizontalAlignment(JLabel.CENTER);
		aboveLabel.setText("Choose the dates of your stay here:");
		roomFrame.add(aboveLabel);
		
		monthBoxStart = new JComboBox(months);
		monthBoxStart.setBounds(380, 220, 120, 25);
		monthBoxStart.addActionListener(this);
		roomFrame.add(monthBoxStart);
		
		dayBoxStart = new JComboBox(days28);
		dayBoxStart.setBounds(510, 220, 50, 25);
		dayBoxStart.addActionListener(this);
		roomFrame.add(dayBoxStart);
		
		yearBoxStart = new JComboBox(years);
		yearBoxStart.setBounds(570, 220, 80, 25);
		yearBoxStart.addActionListener(this);
		roomFrame.add(yearBoxStart);
		
		untilLabel = new JLabel();
		untilLabel.setBounds(310, 255, 388, 40);
		untilLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		untilLabel.setHorizontalAlignment(JLabel.CENTER);
		untilLabel.setText("until");
		roomFrame.add(untilLabel);
		
		monthBoxEnd = new JComboBox(months);
		monthBoxEnd.setBounds(380, 295, 120, 25);
		monthBoxEnd.addActionListener(this);
		roomFrame.add(monthBoxEnd);
		
		dayBoxEnd = new JComboBox(days28);
		dayBoxEnd.setBounds(510, 295, 50, 25);
		dayBoxEnd.addActionListener(this);
		roomFrame.add(dayBoxEnd);
		
		yearBoxEnd = new JComboBox(years);
		yearBoxEnd.setBounds(570, 295, 80, 25);
		yearBoxEnd.addActionListener(this);
		roomFrame.add(yearBoxEnd);
		
		validityLabel = new JLabel();
		validityLabel.setBounds(310, 350, 388, 40);
		validityLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		validityLabel.setForeground(Color.RED);
		validityLabel.setHorizontalAlignment(JLabel.CENTER);
		roomFrame.add(validityLabel);
		
		checkOutButton = new JButton();
		checkOutButton.setBounds(460, 400, 100, 40);
		checkOutButton.setText("Checkout");
		checkOutButton.addActionListener(this);
		roomFrame.add(checkOutButton);
		
		roomFrame.validate();
		roomFrame.repaint();
	}
	
	//Gives the user their bill for staying in the room based on number of days and room class
	//Users are given options to use dollars or the RiCoin currency, which gives a 10% discount
	public void checkOutFrame() {	
		
		riCoinLabel = new JLabel();
		riCoinLabel.setBounds(310, 160, 388, 40);
		riCoinLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		riCoinLabel.setHorizontalAlignment(JLabel.CENTER);
		riCoinLabel.setForeground(new Color(0xFFD700));
		riCoinLabel.setText("Pay with RiCoin (10% discount)");
		roomFrame.add(riCoinLabel);
		
		riCoinPayButton = new JButton();
		riCoinPayButton.setBounds(460, 200, 100, 40);
		riCoinPayButton.setText("Pay");
		riCoinPayButton.addActionListener(this);
		roomFrame.add(riCoinPayButton);
		
		usdLabel = new JLabel();
		usdLabel.setBounds(310, 310, 388, 40);
		usdLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		usdLabel.setHorizontalAlignment(JLabel.CENTER);
		usdLabel.setText("Pay with U.S. Dollars");
		roomFrame.add(usdLabel);
		
		usdPayButton = new JButton();
		usdPayButton.setBounds(460, 350, 100, 40);
		usdPayButton.setText("Pay");
		usdPayButton.addActionListener(this);
		roomFrame.add(usdPayButton);
		
		conversionLabel = new JLabel();
		conversionLabel.setBounds(310, 400, 388, 40);
		conversionLabel.setFont(new Font("Candara", Font.PLAIN, 16));
		conversionLabel.setHorizontalAlignment(JLabel.CENTER);
		conversionLabel.setText("Disclaimer: $1 converts to 10 RiCoin");
		roomFrame.add(conversionLabel);
	}
	
	//Displays the end screen for the user when they finish checking into the room
	//Tells the user what rooms they booked, and allows them to book more rooms if they wish, resetting the check-in process
	public void endScreen() {
		congratulationsLabel1 = new JLabel();
		congratulationsLabel1.setBounds(310, 180, 388, 30);
		congratulationsLabel1.setFont(new Font("Candara", Font.PLAIN, 30));
		congratulationsLabel1.setHorizontalAlignment(JLabel.CENTER);
		congratulationsLabel1.setForeground(new Color(0xFFD700));
		congratulationsLabel1.setText("Congratulations!");
		roomFrame.add(congratulationsLabel1);
		
		congratulationsLabel2 = new JLabel();
		congratulationsLabel2.setBounds(310, 230, 388, 30);
		congratulationsLabel2.setFont(new Font("Candara", Font.PLAIN, 24));
		congratulationsLabel2.setHorizontalAlignment(JLabel.CENTER);
		congratulationsLabel2.setText("You booked Room " + inBookingProcess.getRoomNumber() + "." );
		roomFrame.add(congratulationsLabel2);
		
		bookNewRoom = new JButton();
		bookNewRoom.setBounds(425, 285, 160, 40);
		bookNewRoom.setText("Book Another Room");
		bookNewRoom.addActionListener(this);
		roomFrame.add(bookNewRoom);
		
		yourRoomsBookedLabel = new JLabel();
		yourRoomsBookedLabel.setBounds(310, 360, 388, 30);
		yourRoomsBookedLabel.setFont(new Font("Candara", Font.PLAIN, 24));
		yourRoomsBookedLabel.setHorizontalAlignment(JLabel.CENTER);
		yourRoomsBookedLabel.setText("See all the rooms you've booked:");
		roomFrame.add(yourRoomsBookedLabel);
		
		showYourRooms = new JButton();
		showYourRooms.setBounds(425, 415, 160, 40);
		showYourRooms.setText("Show Your Rooms");
		showYourRooms.addActionListener(this);
		roomFrame.add(showYourRooms);
		
	}
	
	//Resets the labels from the end screen and takes the user to the beginning of the check-in process
	public void resetCheckIn() {
		roomFrame.remove(congratulationsLabel1);
		roomFrame.remove(bookNewRoom);
		roomFrame.remove(congratulationsLabel2);
		roomFrame.remove(yourRoomsBookedLabel);
		roomFrame.remove(showYourRooms);
		
		roomsBookedFrame.setVisible(false);
		roomsBookedFrame.dispose();
		
		step5.setBackground(Color.white);
		step1.setBackground(Color.gray);
		
		checkInInstructions();
		
		inBookingProcess = null;
		bookingProcessRow = -1;
		bookingProcessCol = -1;
		
		roomFrame.validate();
		roomFrame.repaint();
	}
	
	//Clears the checkout screen
	public void removeCheckout() {

		roomFrame.remove(usdLabel);
		roomFrame.remove(riCoinLabel);
		roomFrame.remove(usdPayButton);
		roomFrame.remove(riCoinPayButton);
		roomFrame.remove(conversionLabel);
		step4.setBackground(Color.white);
		step5.setBackground(Color.gray);
		
		roomFrame.validate();
		roomFrame.repaint();
	}
	
	//Creates all of the roomPanels
	public void setRoomPanel() {
		for(int i=0; i<roomPanel.length; i++) {
			for(int j=0; j<roomPanel[0].length; j++) {
				JPanel p = new JPanel();
				JLabel l = new JLabel();
				JButton b = new JButton();
				b.addActionListener(this);
				roomPanel[i][j] = new RoomBoardDisplay(p, l, b, 0);
			}
		}
	}

	public void bookRoom(int row, int col) {
		//Room[][] arr = storage.getRoomList();
		inBookingProcess = arr[row][col];
		bookingProcessRow = row;
		bookingProcessCol = col;
		arr[row][col].setIsBooked(true);
		showRoomBoard();
		for(int i = 0; i<roomPanel.length; i++) {
			for(int j = 0; j<roomPanel[i].length; j++) {
				roomFrame.remove(roomPanel[i][j].getJP());
				roomFrame.remove(roomPanel[i][j].getJL());
				roomFrame.remove(roomPanel[i][j].getJB());
			}
		}
	}
	
	//Returns a date created using the year, month, and day parameters
	public Date setDate(int year, int month, int day) {
		c.set(year, month, day);
		Date tempDate = c.getTime();
		return tempDate;
	}
	
	//Returns the date 'days' after the parameter 'date'
	public Date timeSkip(int days, Date date) {
		Calendar tempCal = Calendar.getInstance();
		Date current = tempCal.getTime();
		tempCal.add(Calendar.DATE, getDaysDifference(current, date));
		tempCal.add(Calendar.DATE, days);
		return tempCal.getTime();	
	}
	
	//Returns the difference between date1 and date2, in days
	public int getDaysDifference(Date date1, Date date2) {
		SimpleDateFormat g = new SimpleDateFormat("DD");
		SimpleDateFormat y = new SimpleDateFormat("yyyy");
		int startyear = Integer.parseInt(y.format(date1));
		int endyear = Integer.parseInt(y.format(date2));
		int yearDiff = endyear - startyear;
		int start = Integer.parseInt(g.format(date1));
		int end = Integer.parseInt(g.format(date2)) + yearDiff*365;
		return end - start;
	}
	
	//Compares two dates to ensure that the end date is later than the start date
	public boolean compareDates() {
		boolean ret = true;
		if(curDate.compareTo(bookingStart) > 0) {
			ret = false;
		}
		else if(bookingStart.compareTo(bookingEnd) >= 0) {
			ret = false;
		}
		
		if(!ret) {
			validityLabel.setText("Your selection of dates is invalid!");
		}
		else {
			validityLabel.setText("");
		}
		return ret;
	}
	
	//Determines if a booking date is valid and sets the booking start date 
	public void setBookingStart() {
		if(monthStart > -1 && dayStart > -1 && yearStart > -1) {
			bookingStart = setDate(yearStart, monthStart, dayStart);
			if(bookingEnd != null) {
				datesValid = compareDates();
			}	
		}
	}
	
	//Determines if a booking date is valid and sets the booking end date 
	public void setBookingEnd() {
		if(monthEnd > -1 && dayEnd > -1 && yearEnd > -1) {
			bookingEnd = setDate(yearEnd, monthEnd, dayEnd);
			if(bookingStart != null) {
				datesValid = compareDates();
			}	
		}
	}
	
	//Gives the user a list of all the rooms that they've booked
	public void showRoomsBooked() {
		roomsBookedFrame = new JFrame();
		roomsBookedFrame.setSize(260, 510);
		roomsBookedFrame.setTitle("Your Rooms");
		roomsBookedFrame.setResizable(false);
		roomsBookedFrame.setLayout(null);
		roomsBookedFrame.getContentPane().setBackground(new Color(0x4287f5));
		roomsBookedFrame.setIconImage(hotelIcon.getImage());
		
		String s = "Your Rooms: \n";
		for(int i=0; i<yourBookedRooms.size(); i++) {
			s += "- " + yourBookedRooms.get(i).getRoomNumber() + "\n";
		}
		
		roomListArea = new JTextArea();
		roomListArea.setBounds(5, 5, 250, 500);
		roomListArea.setBackground(new Color(0x4287f5));
		roomListArea.setEditable(false);
		roomListArea.setFont(new Font("Candara", Font.PLAIN, 24));
		roomListArea.setText(s);
		roomsBookedFrame.add(roomListArea);
		
		roomsBookedFrame.setVisible(true);
	}
	
	//Displays the check in guide upon the button press
	public void showInstructions() {
		instruFrame = new JFrame();
		instruFrame.setSize(360, 700);
		instruFrame.setTitle("Check-In Guide");
		instruFrame.setResizable(false);
		instruFrame.setLayout(null);
		instruFrame.getContentPane().setBackground(new Color(0x4287f5));
		instruFrame.setLayout(new FlowLayout());
		instruFrame.setIconImage(hotelIcon.getImage());
		
		String s = " Check In Information: \n";
		s += "\n";
		s += " 1. Selecting rooms uses a colored grid to represent rooms. \n";
		s += "\n";
		s += " 2. If a displayed room is red then that room is booked. Clicking on it will display \n when it's available. \n";
		s += "\n";
		s += " 3. Bronze squares represent Standard rooms. These rooms cost $150 or 1,500 RiCoin per night. \n";
		s += "\n";
		s += " 4. Silver squares represent Premium rooms. These rooms cost $400 or 4,000 RiCoin per night. \n";
		s += "\n";
		s += " 5. Gold squares represent Presidential rooms. These rooms cost $1000 or 10,000 RiCoin per night. \n";
		s += "\n";
		s += " 6. After choosing a room, you will be prompted to choose the dates of your stay. Choosing dates before the current date, or end dates that come before your start date, will cause a prompt to change your dates. \n";
		s += "\n";
		s += " 7. After checking out, you will have the option to book more rooms if you wish to. \n";
		
		instruArea = new JTextArea();
		instruArea.setBackground(new Color(0x4287f5));
		instruArea.setLineWrap(true);
		instruArea.setWrapStyleWord(true);
		instruArea.setEditable(false);
		instruArea.setFont(new Font("Candara", Font.PLAIN, 16));
		instruFrame.add(instruArea);
		
		instruScroll = new JScrollPane(instruArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		instruScroll.setPreferredSize(new Dimension(350, 750));
		instruFrame.add(instruScroll);
		
		instruArea.setText(s);
		
		instruFrame.setVisible(true);
	}

	//Listens to buttons when ran
	//Includes buttons which switch the step that the user is on
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button) {
			frame.setVisible(false);
			frame.dispose();
			DisplayRooms();
		}
		else if(e.getSource() == b1) {
			if(instruFrame != null) {
				instruFrame.setVisible(false);
				instruFrame.dispose();
			}
			roomFrame.remove(c1);
			roomFrame.remove(c2);
			roomFrame.remove(c3);
			roomFrame.remove(b1);
			roomFrame.remove(b2);
			step1.setBackground(Color.white);
			step2.setBackground(Color.gray);
			showRoomBoard();
			roomFrame.validate();
			roomFrame.repaint();
		}
		else if(e.getSource() == b2) {
			showInstructions();
		}
		else if(e.getSource() == monthBoxStart) {
			Object s = monthBoxStart.getSelectedItem();
			dayStart = -1;
			for(int i=0; i<months.length; i++) {
				if(s.equals(months[i])) {
					monthStart = i - 1;
				}
			}
			if(monthStart == 0 || monthStart == 2 || monthStart == 4 || monthStart == 6 || monthStart == 7 || monthStart == 9 || monthStart == 11) {
				dayBoxStart.setVisible(false);
				roomFrame.remove(dayBoxStart);
				dayBoxStart = new JComboBox(days31);
				dayBoxStart.setBounds(510, 220, 50, 25);
				dayBoxStart.addActionListener(this);
				roomFrame.add(dayBoxStart);
			}
			else if(monthStart == 1) {
				dayBoxStart.setVisible(false);
				roomFrame.remove(dayBoxStart);
				dayBoxStart = new JComboBox(days28);
				dayBoxStart.setBounds(510, 220, 50, 25);
				dayBoxStart.addActionListener(this);
				roomFrame.add(dayBoxStart);
			}
			else {
				dayBoxStart.setVisible(false);
				roomFrame.remove(dayBoxStart);
				dayBoxStart = new JComboBox(days30);
				dayBoxStart.setBounds(510, 220, 50, 25);
				dayBoxStart.addActionListener(this);
				roomFrame.add(dayBoxStart);
			}
			
			setBookingStart();
		}
		else if(e.getSource() == dayBoxStart) {
			Object s = dayBoxStart.getSelectedItem();
			if(!s.equals("DD")) {
				dayStart = Integer.parseInt((String) s);
			}
			
			setBookingStart();
		}
		else if(e.getSource() == yearBoxStart) {
			Object s = yearBoxStart.getSelectedItem();
			if(!s.equals("YYYY")) {
				yearStart = Integer.parseInt((String) s);
			}
			
			setBookingStart();
		}
		// end date boxes
		else if(e.getSource() == monthBoxEnd) {
			Object s = monthBoxEnd.getSelectedItem();
			dayEnd = -1;
			for(int i=0; i<months.length; i++) {
				if(s.equals(months[i])) {
					monthEnd = i - 1;
				}
			}
			if(monthEnd == 0 || monthEnd == 2 || monthEnd == 4 || monthEnd == 6 || monthEnd == 7 || monthEnd == 9 || monthEnd == 11) {
				dayBoxEnd.setVisible(false);
				roomFrame.remove(dayBoxEnd);
				dayBoxEnd = new JComboBox(days31);
				dayBoxEnd.setBounds(510, 295, 50, 25);
				dayBoxEnd.addActionListener(this);
				roomFrame.add(dayBoxEnd);
			}
			else if(monthEnd == 1) {
				dayBoxEnd.setVisible(false);
				roomFrame.remove(dayBoxEnd);
				dayBoxEnd = new JComboBox(days28);
				dayBoxEnd.setBounds(510, 295, 50, 25);
				dayBoxEnd.addActionListener(this);
				roomFrame.add(dayBoxEnd);
			}
			else {
				dayBoxEnd.setVisible(false);
				roomFrame.remove(dayBoxEnd);
				dayBoxEnd = new JComboBox(days30);
				dayBoxEnd.setBounds(510, 295, 50, 25);
				dayBoxEnd.addActionListener(this);
				roomFrame.add(dayBoxEnd);
			}
			
			setBookingEnd();
		}
		else if(e.getSource() == dayBoxEnd) {
			Object s = dayBoxEnd.getSelectedItem();
			if(!s.equals("DD")) {
				dayEnd = Integer.parseInt((String) s);
			}
			
			setBookingEnd();
		}
		else if(e.getSource() == yearBoxEnd) {
			Object s = yearBoxEnd.getSelectedItem();
			if(!s.equals("YYYY")) {
				yearEnd = Integer.parseInt((String) s);
			}
			
			setBookingEnd();
		}
		
		else if(e.getSource() == checkOutButton) {
			if(datesValid) {
				int option = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you would like to stay in " + inBookingProcess.getRoomClass() + " Room " + 
			    inBookingProcess.getRoomNumber() + " for a period of " + getDaysDifference(bookingStart, bookingEnd) + " days.", "Confirm Room", JOptionPane.YES_NO_OPTION);
				if(option == JOptionPane.YES_OPTION) {
					arr[bookingProcessRow][bookingProcessCol].setBookStart(bookingStart);
					arr[bookingProcessRow][bookingProcessCol].setBookEnd(bookingEnd);
					
					roomFrame.remove(aboveLabel);
					roomFrame.remove(untilLabel);
					roomFrame.remove(validityLabel);
					roomFrame.remove(checkOutButton);
					roomFrame.remove(monthBoxStart);
					roomFrame.remove(dayBoxStart);
					roomFrame.remove(yearBoxStart);
					roomFrame.remove(monthBoxEnd);
					roomFrame.remove(dayBoxEnd);
					roomFrame.remove(yearBoxEnd);
					step3.setBackground(Color.white);
					step4.setBackground(Color.gray);
					
					checkOutFrame();
					
					roomFrame.validate();
					roomFrame.repaint();
				}
			}
		}
		
		else if(e.getSource() == riCoinPayButton) {
			int daysBooked = getDaysDifference(bookingStart, bookingEnd);
			int op = 0;
			if(inBookingProcess.getRoomClass().equals("Standard")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying " + 150*9*daysBooked + " RiCoin for a " + daysBooked + " night stay (" + 150*daysBooked + " RiCoin off)", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			else if(inBookingProcess.getRoomClass().equals("Premium")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying " + 400*9*daysBooked + " RiCoin for a " + daysBooked + " night stay (" + 400*daysBooked + " RiCoin off)", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			else if(inBookingProcess.getRoomClass().equals("Presidential")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying " + 1000*9*daysBooked + " RiCoin for a " + daysBooked + " night stay (" + 1000*daysBooked + " RiCoin off)", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			
			if(op == JOptionPane.YES_OPTION) {
				yourBookedRooms.add(inBookingProcess);
				removeCheckout();
				endScreen();
			}
		}
		
		else if(e.getSource() == usdPayButton) {
			int daysBooked = getDaysDifference(bookingStart, bookingEnd);
			int op = 0;
			if(inBookingProcess.getRoomClass().equals("Standard")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying $" + 150*daysBooked + " for a " + daysBooked + " night stay", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			else if(inBookingProcess.getRoomClass().equals("Premium")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying $" + 400*daysBooked + " for a " + daysBooked + " night stay", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			else if(inBookingProcess.getRoomClass().equals("Presidential")) {
				op = JOptionPane.showConfirmDialog(roomFrame, "Confirm that you are paying $" + 1000*daysBooked + " for a " + daysBooked + " night stay", "Final Payment", JOptionPane.YES_NO_OPTION);
			}
			
			if(op == JOptionPane.YES_OPTION) {
				yourBookedRooms.add(inBookingProcess);
				removeCheckout();
				endScreen();
			}
		}
		
		else if(e.getSource() == bookNewRoom) {
			resetCheckIn();
		}
		
		else if(e.getSource() == showYourRooms) {
			showRoomsBooked();
		}
		// choose room panels
		else if(roomFrame != null && roomFrame.isVisible()){
			for(int i=0; i < roomPanel.length; i++) {
				for(int j=0; j<roomPanel[0].length; j++) {
					if(e.getSource() == roomPanel[i][j].getJB()) {
						if(!arr[i][j].getIsBooked()) {
							int op = JOptionPane.showConfirmDialog(roomFrame, "Would you like to book " + arr[i][j].getRoomClass() + " Room " + roomPanel[i][j].getRoomNumber(), "Booking Confirmation", JOptionPane.YES_NO_OPTION);
							if(op == JOptionPane.YES_OPTION) {
								bookRoom(i, j);
								step2.setBackground(Color.white);
								step3.setBackground(Color.gray);
								chooseDates();
								roomFrame.validate();
								roomFrame.repaint();
							}
						}
						else {
							JOptionPane.showMessageDialog(roomFrame, "This room is booked until " + f.format(arr[i][j].getBookEnd()) + " and will become available on " + f.format(timeSkip(1, arr[i][j].getBookEnd())), "Booked Room", JOptionPane.OK_OPTION);
						}
					}
				}
			}
		}
	}
}
