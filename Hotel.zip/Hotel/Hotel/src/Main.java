
public class Main {
	
	//Creates a new frame to start the program
	public static void main(String[] args) {
		Frame f = new Frame();
	}

}
