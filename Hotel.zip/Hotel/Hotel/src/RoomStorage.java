import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//This stores all of the rooms in the hotel
public class RoomStorage {
	
	private static SimpleDateFormat f = new SimpleDateFormat("MM/dd/yyyy");
	private Room[][] roomList = new Room[6][8];
	private static Calendar c = Calendar.getInstance();
	private static final Date startupDate = c.getTime();
	
	//Creates the room list, a 2D array containing all the rooms in the hotel
	public RoomStorage() {
		createRoomList();
	}
	
	//Returns the roomList array
	public Room[][] getRoomList(){
		return roomList;
	}
	
	//Creates the array of rooms with varied numbers and classes
	public void createRoomList() {
		int num = 101;
		for(int r = 0; r < roomList.length; r++) {
			for(int c = 0; c < roomList[0].length; c++) {
				int rand = (int)(Math.random() * 4);
				int randDaysBefore = (int)(Math.random() * 4);
				int randDaysAfter = (int)(Math.random() * 10);
				if(num < 601) {
					if(rand < 3) {
						roomList[r][c] = new Room(num, false, null, null, "Standard");
					}
					else {
						roomList[r][c] = new Room(num, true, timeSkip(randDaysBefore), timeSkip(randDaysAfter), "Standard");
					}
				}
				else if(num < 801) {
					if(rand < 3) {
						roomList[r][c] = new Room(num, false, null, null, "Premium");
					}
					else {
						roomList[r][c] = new Room(num, true, timeSkip(randDaysBefore), timeSkip(randDaysAfter), "Premium");
					}
				}
				else {
					if(rand < 3) {
						roomList[r][c] = new Room(num, false, null, null, "Presidential");
					}
					else {
						roomList[r][c] = new Room(num, true, timeSkip(randDaysBefore), timeSkip(randDaysAfter), "Presidential");
					}
				}
				num += 100;
			}
			num = 101 + (r+1);
		}
	}
	
	//Returns a date that is 'days' days ahead of the current date
	public Date timeSkip(int days) {
		Date temp = startupDate;
		c.add(Calendar.DATE, days);
		temp = c.getTime();
		c.add(Calendar.DATE, -days);
		return temp;	
	}

}
