import java.util.Date;

public class Room {
	private int roomNumber;
	private boolean isBooked;
	private Date bookStart;
	private Date bookEnd;
	private String roomClass;
	
	//Sets instance variables for the room, such as room number, booking dates, and booking status
	//ROOM CLASS DETERMINES ROOM PRICE, STANDARD = $150, PREMIUM = $400, PRESIDENTIAL = $1000
	public Room(int roomNumber, boolean isBooked, Date bookStart, Date bookEnd, String roomClass) {
		this.roomNumber = roomNumber;
		this.isBooked = isBooked;
		this.bookStart = bookStart;
		this.bookEnd = bookEnd;
		this.roomClass = roomClass;
	}
	
	//Returns the room number
	public int getRoomNumber() {return roomNumber;}
	//Returns the booking status
	public boolean getIsBooked() {return isBooked;}
	//Returns the date that the booking starts
	public Date getBookStart() {return bookStart;}
	//Returns the date that the booking ends
	public Date getBookEnd() {return bookEnd;}
	//Returns the class of the room
	public String getRoomClass() {return roomClass;}
	
	//Sets the room number
	public void setRoomNumber(int i) {roomNumber = i;}
	//Sets the booking status
	public void setIsBooked(boolean b) {isBooked = b;}
	//Sets the date that the booking starts
	public void setBookStart(Date i) {bookStart = i;}
	//Sets the date that the booking ends
	public void setBookEnd(Date i) {bookEnd = i;}
	//Sets the class of the room
	public void setRoomClass(String d) {roomClass = d;}
}
