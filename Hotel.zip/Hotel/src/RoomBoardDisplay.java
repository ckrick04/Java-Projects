import javax.swing.*;
import java.awt.*;

public class RoomBoardDisplay {
	
	private JPanel jp;
	private JLabel jl;
	private JButton jb;
	private int roomNumber;
	
	//Sets the components of the RoomBoardDisplay panel
	public RoomBoardDisplay(JPanel j, JLabel l, JButton b, int r){
		jp = j;
		jl = l;
		jb = b;
		roomNumber = r;
	}
	
	//Returns the JPanel for the display
	public JPanel getJP() {return jp;}
	//Returns the JLabel for the display
	public JLabel getJL() {return jl;}
	//Returns the JButton for the display
	public JButton getJB() {return jb;}
	//Returns the room number displayed
	public int getRoomNumber() {return roomNumber;}
	
	//Sets the JPanel
	public void setJP(JPanel jp) {this.jp = jp;}
	//Sets the JLabel
	public void setJL(JLabel jl) {this.jl = jl;}
	//Sets the JButton
	public void setJB(JButton jb) {this.jb = jb;}
	//Sets the room number
	public void setRoomNumber(int roomNumber) {this.roomNumber = roomNumber;}
}
