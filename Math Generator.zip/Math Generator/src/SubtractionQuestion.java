
public class SubtractionQuestion extends Question{

	private static final int minNum = 1;
	private static final int maxNum = 150;
	private static final int minAnswer = 0;
	private static final int maxAnswer = 100;
	
	public SubtractionQuestion() {
		super();
	}
	
	//Generates a random number between minNum and maxNum
	@Override
	public int generateNum1() {
		return (int)(minNum + Math.random() * (maxNum - minNum + 1));
	}
	
	//Generates a random number between minNum and maxNum
	//The method will repeat if the difference is greater than maxAnswer
	@Override
	public int generateNum2() {
		int num2 = (int)(minNum + Math.random() * (maxNum - minNum + 1));
		while(getNum1() - num2 < minAnswer || getNum1() - num2 > maxAnswer) {
			num2 = (int)(minNum + Math.random() * (maxNum - minNum + 1));
		}
		return num2;
	}
	
	//Returns the answer, the difference of num1 and num2
	@Override
	public int getAnswer() {
		return getNum1() - getNum2();
	}
	
	//Returns a string version of the question
	@Override
	public String toString() {
		return getNum1() + " - " + getNum2();
	}

}
