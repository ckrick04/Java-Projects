import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class QuizGUI implements ActionListener, KeyListener{
	
	private QuizHandler quizHandler;
	
	private JFrame frame;
	private JLabel questionLabel;
	private JLabel questionNumber;
	private JButton enterButton;
	private JButton forwardButton;
	private JButton backButton;
	private JButton submitButton;
	private JTextField answerField;
	
	//Creates the QuizGUI and its components
	public QuizGUI(JFrame frame, QuizHandler quizHandler) {
		this.frame = frame;
		this.quizHandler = quizHandler;
		
		initializeButtons();
		initializeLabels();
		initializeTextFields();
		
		frame.validate();
		frame.repaint();
	}
	
	//Creates all buttons to be displayed on the QuizGUI frame
	public void initializeButtons() {
		backButton = new JButton();
		backButton.setBounds(0, 0, 50, 50);
		backButton.setText("<");
		backButton.addActionListener(this);
		frame.add(backButton);
		
		forwardButton = new JButton();
		forwardButton.setBounds(535, 0, 50, 50);
		forwardButton.setText(">");
		forwardButton.addActionListener(this);
		frame.add(forwardButton);
		
		submitButton = new JButton();
		submitButton.setBounds(200, 250, 200, 50);
		submitButton.setText("Submit");
		submitButton.addActionListener(this);
		if(quizHandler.getNumQuestions() == 1) {
			submitButton.setVisible(true);
		}
		else{
			submitButton.setVisible(false);
		}
		frame.add(submitButton);
	}
	
	//Creates all labels to be displayed on the QuizGUI frame
	public void initializeLabels() {
		questionNumber = new JLabel();
		questionNumber.setBounds(100, 0, 400, 50);
		questionNumber.setText(quizHandler.getCurQuestion() + 1 + "/" + quizHandler.getNumQuestions());
		questionNumber.setHorizontalAlignment(JLabel.CENTER);
		questionNumber.setVerticalAlignment(JLabel.CENTER);
		questionNumber.setFont(new Font("Verdana", Font.BOLD, 18));
		frame.add(questionNumber);
		
		questionLabel = new JLabel();
		questionLabel.setBounds(100, 50, 400, 100);
		questionLabel.setHorizontalAlignment(JLabel.CENTER);
		questionLabel.setVerticalAlignment(JLabel.CENTER);
		questionLabel.setFont(new Font("Verdana", Font.PLAIN, 24));
		questionLabel.setText(quizHandler.getQuestions()[quizHandler.getCurQuestion()].toString());
		frame.add(questionLabel);
	}
	
	//Creates all text fields to be displayed on the QuizGUI frame
	public void initializeTextFields() {
		answerField = new JTextField();
		answerField.setBounds(250, 150, 100, 50);
		answerField.setFont(new Font("Verdana", Font.PLAIN, 24));
		answerField.setHorizontalAlignment(JTextField.CENTER);
		answerField.addKeyListener(this);
		frame.add(answerField);
	}
	
	//Sets the answer using the QuizHandler
	public void setAnswer() {
		if(!answerField.getText().equals("")) {
			int ans = Integer.parseInt(answerField.getText());
			quizHandler.setAnswer(quizHandler.getCurQuestion(), ans);
		}
		else {
			quizHandler.setAnswer(quizHandler.getCurQuestion(), -1);
		}
	}
	
	//Changes the question upon clicking the left or right arrows on screen
	public void changeQuestion(int x) {
		//x = 1 to go forward 1, x = -1 to go back 1
		quizHandler.changeCurQuestion(x);
		questionLabel.setText(quizHandler.getQuestions()[quizHandler.getCurQuestion()].toString());
		questionNumber.setText(quizHandler.getCurQuestion() + 1 + "/" + quizHandler.getNumQuestions());
		if(quizHandler.getAnswers()[quizHandler.getCurQuestion()] != -1) {
			answerField.setText("" + quizHandler.getAnswers()[quizHandler.getCurQuestion()]);
		}
		else {
			answerField.setText("");
		}
		if(quizHandler.getCurQuestion() == quizHandler.getNumQuestions() - 1) {
			submitButton.setVisible(true);
		}
		else {
			submitButton.setVisible(false);
		}
	}
	
	//Determines if a typed character is a numerical digit
	public boolean isDigit(char c) {
		char[] digits = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};
		for(char d : digits) {
			if(c == d) {
				return true;
			}
		}
		return false;
	}
	
	//ActionPerformed method for buttons and text fields
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == forwardButton) {
			if(quizHandler.getCurQuestion() < quizHandler.getQuestions().length - 1) {
				setAnswer();
				changeQuestion(1);
			}
		}
		else if(e.getSource() == backButton) {
			if(quizHandler.getCurQuestion() > 0) {
				setAnswer();
				changeQuestion(-1);
			}
		}
		else if(e.getSource() == submitButton) {
			setAnswer();
			frame.dispose();
			ResultsGUI results = new ResultsGUI(quizHandler);
		}
	}
	
	//KeyTyped method that activates when a key is typed (for text fields)
	@Override
	public void keyTyped(KeyEvent e) {
		if(e.getSource() == answerField && !isDigit(e.getKeyChar())) {
			e.consume();
		}
		else if(e.getSource() == answerField && answerField.getText().length() == 4) {
			e.consume();
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

}
