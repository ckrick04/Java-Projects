import java.util.ArrayList;
import java.util.List;

public class QuizHandler {
	
	private int numQuestions;
	private Question[] questions;
	private int[] answers;
	private boolean[] results;
	private int curQuestion;
	
	private boolean additionEnabled;
	private boolean subtractionEnabled;
	private boolean multiplicationEnabled;
	private boolean divisionEnabled;
	
	//Sets variables of the quiz handler class, such as the questions, answers, and eventual results
	public QuizHandler(int numQuestions, boolean[] typesEnabled) {
		
		this.numQuestions = numQuestions;
		questions = new Question[numQuestions];
		answers = new int[numQuestions];
		results = new boolean[numQuestions];
		curQuestion = 0;
		setAllUnanswered();
		
		additionEnabled = typesEnabled[0];
		subtractionEnabled = typesEnabled[1];
		multiplicationEnabled = typesEnabled[2];
		divisionEnabled = typesEnabled[3];
		
		setQuestions();
	}
	
	//Creates the list of questions using the number of questions and types of questions enabled
	public void setQuestions() {
		List<String> typesEnabled = getTypesEnabled();
		int numEnabled = typesEnabled.size();
		for(int i = 0; i < numQuestions; i++) {
			int num = (int)(Math.random() * numEnabled);
			if(typesEnabled.get(num).equals("Addition")) {
				questions[i] = new AdditionQuestion();
			}
			else if(typesEnabled.get(num).equals("Subtraction")) {
				questions[i] = new SubtractionQuestion();
			}
			else if(typesEnabled.get(num).equals("Multiplication")) {
				questions[i] = new MultiplicationQuestion();
			}
			else {
				questions[i] = new DivisionQuestion();
			}
		}
	}
	
	//Prints all questions (for debugging)
	public void printQuestions() {
		for(int i=0; i<questions.length; i++) {
			if(questions[i].getClass().getName().equals("AdditionQuestion")) {
				System.out.println(questions[i].getNum1() + " + " + questions[i].getNum2() + " = " + questions[i].getAnswer());
			}
			else if(questions[i].getClass().getName().equals("SubtractionQuestion")) {
				System.out.println(questions[i].getNum1() + " - " + questions[i].getNum2() + " = " + questions[i].getAnswer());
			}
			else if(questions[i].getClass().getName().equals("MultiplicationQuestion")) {
				System.out.println(questions[i].getNum1() + " x " + questions[i].getNum2() + " = " + questions[i].getAnswer());
			}
			else {
				System.out.println(questions[i].getNum1() + " � " + questions[i].getNum2() + " = " + questions[i].getAnswer());
			}
		}
	}
	
	//Returns the list of types of enabled questions
	private List<String> getTypesEnabled(){
		List<String> ret = new ArrayList<String>();
		if(additionEnabled) {
			ret.add("Addition");
		}
		if(subtractionEnabled) {
			ret.add("Subtraction");
		}
		if(multiplicationEnabled) {
			ret.add("Multiplication");
		}
		if(divisionEnabled) {
			ret.add("Division");
		}
		return ret;
	}
	
	//Sets all answers to -1 (A question's answer being -1 makes it considered unanswered)
	public void setAllUnanswered() {
		for(int i=0; i<answers.length; i++) {
			answers[i] = -1;
		}
	}
	
	//Sets the user given answer at a specific index
	public void setAnswer(int index, int answer) {
		answers[index] = answer;
	}
	
	//Sets the results array, where true indicates that the question at a given index had the right answer provided
	public void setResults() {
		for(int i=0; i<numQuestions; i++) {
			results[i] = (questions[i].getAnswer() == answers[i]);
		}
	}
	
	//Returns the number of correct answers in a given quiz
	public int getNumCorrect() {
		int cnt = 0;
		for(int i=0; i<numQuestions; i++) {
			if(questions[i].getAnswer() == answers[i]) {
				cnt++;
			}
		}
		return cnt;
	}
	
	//Returns the array of questions
	public Question[] getQuestions() {return questions;}
	//Returns the number of questions
	public int getNumQuestions() {return numQuestions;}
	//Returns the array of inputted answers
	public int[] getAnswers() {return answers;}
	//Returns the array of boolean results (correct vs incorrect)
	public boolean[] getResults() {return results;}
	//Returns the selected question
	public int getCurQuestion() {return curQuestion;}
	
	//Returns whether or not addition questions are to be part of the quiz
	public boolean getAdditionEnabled() {return additionEnabled;}
	//Returns whether or not subtraction questions are to be part of the quiz
	public boolean getSubtractionEnabled() {return subtractionEnabled;}
	//Returns whether or not multiplication questions are to be part of the quiz
	public boolean getMultiplicationEnabled() {return multiplicationEnabled;}
	//Returns whether or not division questions are to be part of the quiz
	public boolean getDivisionEnabled() {return divisionEnabled;}
	
	//Changes the current question to a specific index of the questions array
	public void changeCurQuestion(int x) {curQuestion += x;}
}
