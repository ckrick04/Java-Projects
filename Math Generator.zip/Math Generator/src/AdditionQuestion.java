
public class AdditionQuestion extends Question {
	
	private static final int answerLimit = 100;
	
	public AdditionQuestion() {
		super();
	}
	
	//Generates a number from 0 to answerLimit - 1
	@Override
	public int generateNum1() {
		return (int)(Math.random() * answerLimit);
	}
	
	//Generates a number from 1 to the difference between the answer limit and the first number generated
	@Override
	public int generateNum2() {
		return (int)(1 + Math.random() * (answerLimit - getNum1()));
	}
	
	//Returns the answer (first number + second number)
	@Override
	public int getAnswer() {
		return getNum1() + getNum2();
	}
	
	//Returns a string version of the question
	@Override
	public String toString() {
		return getNum1() + " + " + getNum2();
	}

}
