//Acts as a general template for different types of questions
public abstract class Question {
	
	private int num1;
	private int num2;
	
	//Generates two numbers using abstract methods defined for each type of question
	//(Addition, Subtraction, Multiplication, Division)
	public Question() {
		num1 = generateNum1();
		num2 = generateNum2();
	}
	
	//Generates the two numbers used in the problem
	public abstract int generateNum1();
	public abstract int generateNum2();
	
	//Gets the answer to the problem
	public abstract int getAnswer();
	
	//Gets num1 and num2
	public int getNum1() {return num1;}
	public int getNum2() {return num2;}
	
	//Sets num1 and num2
	public void setNum1(int x) {num1 = x;}
	public void setNum2(int x) {num2 = x;}
	
	//toString
	public abstract String toString();
}
