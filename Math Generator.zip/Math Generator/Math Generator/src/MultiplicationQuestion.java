//Class for creating multiplication questions
public class MultiplicationQuestion extends Question{
	
	private static final int minNum = 2;
	private static final int maxNum = 20;
	private static final int maxAnswer = 100;
	
	public MultiplicationQuestion() {
		super();
	}
	
	//Generates a number between the minNum and maxNum
	@Override
	public int generateNum1() {
		return (int)(minNum + Math.random() * (maxNum - minNum + 1));
	}
	
	//Generates a number that meets the parameters of the first number
	//This method will repeat if the product of the two numbers is greater than maxAnswer
	@Override
	public int generateNum2() {
		int num2 = (int)(minNum + Math.random() * (maxNum - minNum + 1));
		while(num2 * getNum1() > maxAnswer) {
			num2 = (int)(minNum + Math.random() * (maxNum - minNum + 1));
		}
		return num2;
	}
	
	//Returns the answer, the product of the two numbers
	@Override
	public int getAnswer() {
		return getNum1() * getNum2();
	}
	
	//Returns a string version of the question
	@Override
	public String toString() {
		return getNum1() + " x " + getNum2();
	}

}
