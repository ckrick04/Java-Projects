import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.Border;

//Allows users to configure the number of and types of questions on the quiz
public class StartQuizGUI implements ActionListener, KeyListener{
	
	private int numQuestions;
	private boolean[] questionTypesEnabled = {true, true, true, true};
	private final String[] questionTypes = {"Addition", "Subtraction", "Multiplication", "Division"};
	
	private QuizHandler quizHandler;
	
	private JFrame frame;
	private JLabel setNumQuestionsLabel;
	private JLabel chooseQuestionTypes;
	private JLabel startQuizLabel;
	private JButton[] questionTypeButtons;
	private JButton startButton;
	private JTextField setNumQuestionsField;
	
	//Sets the StartQuizGUI, which allows users to change settings going into a quiz
	public StartQuizGUI() {
		numQuestions = 0;
		initializeFrame();
		initializeButtons();
		initializeLabels();
		initializeTextFields();
		frame.setVisible(true);
	}
	
	//Creates the basic frame for the gui
	public void initializeFrame() {
		frame = new JFrame();
		frame.setSize(600, 400);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Quiz");
		frame.setLayout(null);
	}
	
	//Creates the buttons that will be displayed on the gui
	public void initializeButtons() {
		questionTypeButtons = new JButton[4];
		int x = 50;
		for(int i = 0; i<questionTypeButtons.length; i++) {
			questionTypeButtons[i] = new JButton();
			questionTypeButtons[i].setBounds(x, 150, 100, 40);
			questionTypeButtons[i].setText(questionTypes[i]);
			questionTypeButtons[i].addActionListener(this);
			questionTypeButtons[i].setBorder(BorderFactory.createLineBorder(Color.green));
			frame.add(questionTypeButtons[i]);
			x += 125;
		}
		
		startButton = new JButton();
		startButton.setBounds(260, 260, 80, 40);
		startButton.setText("Start");
		startButton.addActionListener(this);
		frame.add(startButton);
	}
	
	//Creates all labels for the GUI
	public void initializeLabels() {
		setNumQuestionsLabel = new JLabel();
		setNumQuestionsLabel.setBounds(175, 50, 125, 37);
		setNumQuestionsLabel.setText("Questions:");
		setNumQuestionsLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
		setNumQuestionsLabel.setHorizontalAlignment(JLabel.CENTER);
		setNumQuestionsLabel.setVerticalAlignment(JLabel.CENTER);
		frame.add(setNumQuestionsLabel);
		
		chooseQuestionTypes = new JLabel();
		chooseQuestionTypes.setBounds(100, 100, 400, 50);
		chooseQuestionTypes.setText("Select Which Types of Questions to Practice");
		chooseQuestionTypes.setFont(new Font("Verdana", Font.PLAIN, 16));
		chooseQuestionTypes.setHorizontalAlignment(JLabel.CENTER);
		chooseQuestionTypes.setVerticalAlignment(JLabel.CENTER);
		frame.add(chooseQuestionTypes);
		
		startQuizLabel = new JLabel();
		startQuizLabel.setBounds(100, 200, 400, 50);
		startQuizLabel.setText("Ready? Click 'Start' to Begin Your Quiz!");
		startQuizLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
		startQuizLabel.setHorizontalAlignment(JLabel.CENTER);
		startQuizLabel.setVerticalAlignment(JLabel.CENTER);
		frame.add(startQuizLabel);
	}
	
	//Creates all text fields for the gui
	public void initializeTextFields() {
		setNumQuestionsField = new JTextField();
		setNumQuestionsField.setBounds(300, 50, 75, 40);
		setNumQuestionsField.setFont(new Font("Verdana", Font.PLAIN, 16));
		setNumQuestionsField.addKeyListener(this);
		frame.add(setNumQuestionsField);
	}
	
	//Clears the screen to add the main quiz gui elements
	public void clearConfigureQuizScreen() {
		setNumQuestionsField.setVisible(false);
		setNumQuestionsLabel.setVisible(false);
		chooseQuestionTypes.setVisible(false);
		setNumQuestionsField.setVisible(false);
		startQuizLabel.setVisible(false);
		
		for(int i=0; i<questionTypeButtons.length; i++) {
			questionTypeButtons[i].setVisible(false);
		}
		
		startButton.setVisible(false);
	}
	
	//Creates a quiz gui and begins the quiz
	public void startQuiz() {
		quizHandler = new QuizHandler(numQuestions, questionTypesEnabled);
		QuizGUI quiz = new QuizGUI(frame, quizHandler);
	}
	
	//Determines if a typed character is a numerical digit
	public boolean isDigit(char c) {
		char[] digits = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};
		for(char d : digits) {
			if(c == d) {
				return true;
			}
		}
		return false;
	}
	
	//actionPerformed method to use buttons and textfields
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == startButton) {
			String s = setNumQuestionsField.getText();
			if(!(s.equals("") || s.equals("0"))) {
				numQuestions = Integer.parseInt(s);
				clearConfigureQuizScreen();
				startQuiz();
			}
		}
		for(int i=0; i<questionTypeButtons.length; i++) {
			if(e.getSource() == questionTypeButtons[i]) {
				questionTypesEnabled[i] = !questionTypesEnabled[i];
				if(questionTypesEnabled[i]) {
					questionTypeButtons[i].setBorder(BorderFactory.createLineBorder(Color.green));
				}
				else {
					questionTypeButtons[i].setBorder(BorderFactory.createLineBorder(Color.gray));
				}
			}
		}
		
	}

	//detects when a key is typed into the text field, checks it to ensure that its a digit or if the text in the text field is too long
	//deletes the text if it doesn't meet these conditions
	@Override
	public void keyTyped(KeyEvent e) {
		if(e.getSource() == setNumQuestionsField && !isDigit(e.getKeyChar())) {
			e.consume();
		}
		if(e.getSource() == setNumQuestionsField && setNumQuestionsField.getText().length() == 2) {
			e.consume();
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

}
