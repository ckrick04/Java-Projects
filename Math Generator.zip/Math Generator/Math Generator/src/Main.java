import javax.swing.JFrame;

public class Main {
	
	//Creates the quiz gui 
	public static void main(String[] args) {
		StartQuizGUI gui = new StartQuizGUI();
	}

}
