import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//Displays the results of the quiz to the user
public class ResultsGUI implements ActionListener{
	
	private QuizHandler quizHandler;
	
	private int addQuestionsCorrect;
	private int addQuestionsIncorrect;
	private int subQuestionsCorrect;
	private int subQuestionsIncorrect;
	private int multQuestionsCorrect;
	private int multQuestionsIncorrect;
	private int divQuestionsCorrect;
	private int divQuestionsIncorrect;
	
	private JFrame frame;
	private String[] questionList;
	private JLabel scoreLabel;
	private JLabel correctIncorrectLabel;
	private JLabel additionLabel;
	private JLabel subtractionLabel;
	private JLabel multiplicationLabel;
	private JLabel divisionLabel;
	private JLabel yourAnswer;
	private JLabel correctAnswer;
	private JLabel comboBoxLabel;
	private JLabel yourAnswerLabel;
	private JLabel correctAnswerLabel;
	private JPanel[] statBars;
	private JButton newQuiz;
	private JComboBox questionBox;
	
	//Creates the quiz results gui 
	public ResultsGUI(QuizHandler quizHandler) {
		this.quizHandler = quizHandler;
		setQuestionTypeVars();
		setQuestionList();
		initializeFrame();
		initializeLabels();
		initializeButtons();
		initializeBars();
		initializeComboBox();
		frame.setVisible(true);
	}
	
	//Creates the frame for the results gui
	public void initializeFrame() {
		frame = new JFrame();
		frame.setSize(800, 560);
		frame.setResizable(false);
		frame.setTitle("Results");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
	}
	
	//Creates all labels for the gui, including the score and numbers of each type of question given
	public void initializeLabels() {
		scoreLabel = new JLabel();
		scoreLabel.setBounds(100, 0, 600, 30);
		scoreLabel.setFont(new Font("Verdana", Font.PLAIN, 28));
		scoreLabel.setHorizontalAlignment(JLabel.CENTER);
		scoreLabel.setVerticalAlignment(JLabel.CENTER);
		scoreLabel.setText("Your Score: " + getPercentageScoreString() + "%");
		frame.add(scoreLabel);
		
		correctIncorrectLabel = new JLabel();
		correctIncorrectLabel.setBounds(100, 30, 600, 60);
		correctIncorrectLabel.setFont(new Font("Verdana", Font.PLAIN, 20));
		correctIncorrectLabel.setHorizontalAlignment(JLabel.CENTER);
		correctIncorrectLabel.setVerticalAlignment(JLabel.CENTER);
		correctIncorrectLabel.setText("Correct: " + quizHandler.getNumCorrect() + "       Incorrect: " + (quizHandler.getNumQuestions() - quizHandler.getNumCorrect()));
		frame.add(correctIncorrectLabel);
		
		additionLabel = new JLabel();
		additionLabel.setBounds(0, 80, 100, 50);
		additionLabel.setFont(new Font("Verdana", Font.BOLD, 14));
		additionLabel.setHorizontalAlignment(JLabel.CENTER);
		additionLabel.setVerticalAlignment(JLabel.CENTER);
		additionLabel.setText("Addition");
		frame.add(additionLabel);
		
		subtractionLabel = new JLabel();
		subtractionLabel.setBounds(0, 150, 100, 50);
		subtractionLabel.setFont(new Font("Verdana", Font.BOLD, 14));
		subtractionLabel.setHorizontalAlignment(JLabel.CENTER);
		subtractionLabel.setVerticalAlignment(JLabel.CENTER);
		subtractionLabel.setText("Subtraction");
		frame.add(subtractionLabel);
		
		multiplicationLabel = new JLabel();
		multiplicationLabel.setBounds(0, 220, 100, 46);
		multiplicationLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		multiplicationLabel.setHorizontalAlignment(JLabel.CENTER);
		multiplicationLabel.setVerticalAlignment(JLabel.CENTER);
		multiplicationLabel.setText("Multiplication");
		frame.add(multiplicationLabel);
		
		divisionLabel = new JLabel();
		divisionLabel.setBounds(0, 290, 100, 50);
		divisionLabel.setFont(new Font("Verdana", Font.BOLD, 14));
		divisionLabel.setHorizontalAlignment(JLabel.CENTER);
		divisionLabel.setVerticalAlignment(JLabel.CENTER);
		divisionLabel.setText("Division");
		frame.add(divisionLabel);
		
		yourAnswer = new JLabel();
		yourAnswer.setBounds(170, 400, 150, 50);
		yourAnswer.setHorizontalAlignment(JLabel.CENTER);
		yourAnswer.setVerticalAlignment(JLabel.CENTER);
		yourAnswer.setFont(new Font("Verdana", Font.BOLD, 20));
		yourAnswer.setText(quizHandler.getAnswers()[0] + "");
		if(quizHandler.getAnswers()[0] != quizHandler.getQuestions()[0].getAnswer()) {
			yourAnswer.setForeground(Color.red);
			if(quizHandler.getAnswers()[0] == -1) {
				yourAnswer.setText("N/A");
			}
		}
		frame.add(yourAnswer);
		
		correctAnswer = new JLabel();
		correctAnswer.setBounds(320, 400, 150, 50);
		correctAnswer.setFont(new Font("Verdana", Font.BOLD, 20));
		correctAnswer.setHorizontalAlignment(JLabel.CENTER);
		correctAnswer.setVerticalAlignment(JLabel.CENTER);
		correctAnswer.setText(quizHandler.getQuestions()[0].getAnswer() + "");
		frame.add(correctAnswer);
		
		comboBoxLabel = new JLabel();
		comboBoxLabel.setBounds(20, 350, 150, 50);
		comboBoxLabel.setFont(new Font("Verdana", Font.PLAIN, 12));
		comboBoxLabel.setText("View Questions");
		comboBoxLabel.setHorizontalAlignment(JLabel.CENTER);
		comboBoxLabel.setVerticalAlignment(JLabel.CENTER);
		frame.add(comboBoxLabel);
		
		yourAnswerLabel = new JLabel();
		yourAnswerLabel.setBounds(170, 350, 150, 50);
		yourAnswerLabel.setHorizontalAlignment(JLabel.CENTER);
		yourAnswerLabel.setVerticalAlignment(JLabel.CENTER);
		yourAnswerLabel.setFont(new Font("Verdana", Font.PLAIN, 12));
		yourAnswerLabel.setText("Your Answer");
		frame.add(yourAnswerLabel);
		
		correctAnswerLabel = new JLabel();
		correctAnswerLabel.setBounds(320, 350, 150, 50);
		correctAnswerLabel.setHorizontalAlignment(JLabel.CENTER);
		correctAnswerLabel.setVerticalAlignment(JLabel.CENTER);
		correctAnswerLabel.setFont(new Font("Verdana", Font.PLAIN, 12));
		correctAnswerLabel.setText("Correct Answer");
		frame.add(correctAnswerLabel);
	}
	
	//Creates the button to start a new quiz
	public void initializeButtons() {
		newQuiz = new JButton();
		newQuiz.setBounds(520, 400, 200, 50);
		newQuiz.setText("Start A New Quiz");
		newQuiz.addActionListener(this);
		frame.add(newQuiz);
	}
	
	//Creates the bars which show the ratio of questions correct to incorrect
	public void initializeBars() {
		statBars = new JPanel[8];
		int x = 150;
		int y = 80;
		setBarPair(0, x, y, addQuestionsCorrect, addQuestionsIncorrect);
		setBarPair(2, x, y+70, subQuestionsCorrect, subQuestionsIncorrect);
		setBarPair(4, x, y+140, multQuestionsCorrect, multQuestionsIncorrect);
		setBarPair(6, x, y+210, divQuestionsCorrect, divQuestionsIncorrect);
	}
	
	//Sets a list of questions (displayed as strings using the toString method of each question)
	public void setQuestionList() {
		questionList = new String[quizHandler.getNumQuestions()];
		for(int i=0; i<questionList.length; i++) {
			questionList[i] = (i+1) + ". " + quizHandler.getQuestions()[i].toString();
		}
	}
	
	//Creates the combobox which allows users to select a specific question from a list of all questions
	public void initializeComboBox() {
		questionBox = new JComboBox(questionList);
		questionBox.setBounds(20, 400, 150, 50);
		questionBox.setFont(new Font("Verdana", Font.PLAIN, 16));
		questionBox.addActionListener(this);
		frame.add(questionBox);
	}
	
	//Creates visual bars for correct and incorrect questions
	public void setBarPair(int i, int x, int y, int correct, int wrong) {
		int numQuestions = quizHandler.getNumQuestions();
		if((correct+wrong) > 0) {
			statBars[i] = new JPanel();
			statBars[i+1] = new JPanel();
			int cLength = (int)(500*(1.0*correct/numQuestions));
			int wLength = (int)(500*(1.0*wrong/numQuestions));
			JPanel a = statBars[i];
			JPanel b = statBars[i+1];
			JLabel al = new JLabel();
			JLabel bl = new JLabel();
			a.setBackground(Color.green);
			a.setBounds(x, y, cLength, 25);
			al.setBounds(x+cLength, y, 50, 25);
			al.setText(correct + "");
			frame.add(a);
			frame.add(al);
			y += 25;
			b.setBackground(Color.red);
			b.setBounds(x, y, wLength, 25);
			bl.setBounds(x+wLength, y, 50, 25);
			bl.setText(wrong + "");
			frame.add(b);
			frame.add(bl);
		}
		else {
			JLabel na = new JLabel();
			na.setBounds(x, y, 200, 50);
			na.setFont(new Font("Verdana", Font.PLAIN, 14));
			na.setHorizontalAlignment(JLabel.LEFT);
			na.setVerticalAlignment(JLabel.CENTER);
			na.setText("None Answered");
			frame.add(na);
		}
	}
	
	//Modifies instance variables using the types of questions for each question in the quiz and the correctness of the question
	//Once these are determined, the corresponding instance variable is incremented
	public void setQuestionTypeVars() {
		for(int i=0; i<quizHandler.getQuestions().length; i++) {
			Question[] questions = quizHandler.getQuestions();
			int[] answers = quizHandler.getAnswers();
			if(questions[i].getAnswer() == answers[i]) {
				if(questions[i].getClass().getName().equals("AdditionQuestion")) {
					addQuestionsCorrect++;
				}
				else if(questions[i].getClass().getName().equals("SubtractionQuestion")) {
					subQuestionsCorrect++;
				}
				else if(questions[i].getClass().getName().equals("MultiplicationQuestion")) {
					multQuestionsCorrect++;
				}
				else {
					divQuestionsCorrect++;
				}
			}
			else {
				if(questions[i].getClass().getName().equals("AdditionQuestion")) {
					addQuestionsIncorrect++;
				}
				else if(questions[i].getClass().getName().equals("SubtractionQuestion")) {
					subQuestionsIncorrect++;
				}
				else if(questions[i].getClass().getName().equals("MultiplicationQuestion")) {
					multQuestionsIncorrect++;
				}
				else {
					divQuestionsIncorrect++;
				}
			}
		}
	}
	
	//Converts the percentage score into a string
	public String getPercentageScoreString() {
		double score = 100.0*quizHandler.getNumCorrect()/quizHandler.getNumQuestions();
		String ret = "";
		String strScore = "" + score;
		for(int i=0; i<strScore.length(); i++) {
			if(!strScore.substring(i, i+1).equals(".")) {
				ret += strScore.substring(i, i+1);
			}
			else {
				ret += strScore.substring(i, i+2);
				return ret;
			}
		}
		return ret;
	}
	
	//actionPerformed method to detect use of buttons and comboboxes
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == questionBox) {
			int index = questionBox.getSelectedIndex();
			yourAnswer.setText(quizHandler.getAnswers()[index] + "");
			correctAnswer.setText(quizHandler.getQuestions()[index].getAnswer() + "");
			if(quizHandler.getAnswers()[index] != quizHandler.getQuestions()[index].getAnswer()) {
				yourAnswer.setForeground(Color.red);
				if(quizHandler.getAnswers()[index] == -1) {
					yourAnswer.setText("N/A");
				}
			}
			else {
				yourAnswer.setForeground(Color.black);
			}
		}
		else if(e.getSource() == newQuiz) {
			frame.dispose();
			StartQuizGUI gui = new StartQuizGUI();
		}
	}
}
