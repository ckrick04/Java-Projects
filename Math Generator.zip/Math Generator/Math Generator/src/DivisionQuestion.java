import java.util.ArrayList;
import java.util.List;

//Class for creating division questions
public class DivisionQuestion extends Question {
	
	private static final int minNum1 = 25;
	private static final int maxNum1 = 150;
	private static final int minNum2 = 2;
	private static final int maxNum2 = 30;
	private static final int maxAnswer = 100;
	
	private List<Integer> possibleDivisors;
	
	public DivisionQuestion() {
		super();
	}
	
	//Generates a random number between minNum1 and maxNum1
	@Override
	public int generateNum1() {
		return (int)(minNum1 + Math.random() * (maxNum1 - minNum1 + 1));
	}
	
	//Generates a random number between minNum2 and maxNum2 that is divisible to the first number and less than maxAnswer
	@Override
	public int generateNum2() {
		int n2 = 1;
		possibleDivisors = getPossibleDivisors(getNum1(), minNum2, maxNum2);
		while(possibleDivisors.size() == 0 || getNum1()/n2 > maxAnswer) {
			setNum1(generateNum1());
			possibleDivisors = getPossibleDivisors(getNum1(), minNum2, maxNum2);
		}
		n2 = possibleDivisors.get((int)(Math.random() * possibleDivisors.size()));
		return n2;
	}
	
	//Returns the answer, the quotient of the first and second numbers
	@Override
	public int getAnswer() {
		return getNum1() / getNum2();
	}
	
	//Determines if n2 is divisible by n1
	private boolean isDivisible(int n1, int n2) {
		double dn1 = 1.0 * n1;
		double dn2 = 1.0 * n2;
		double numDiv = dn1/dn2;
		int numDivInt = (int)(numDiv);
		if(numDiv - numDivInt == 0.0) {
			return true;
		}
		return false;
	}
	
	//Creates a list of possible divisors for a specific number
	public List<Integer> getPossibleDivisors(int num, int minDivisor, int maxDivisor){
		List<Integer> divisors = new ArrayList<Integer>();
		for(int i = minDivisor; i <= maxDivisor; i++) {
			if(isDivisible(num, i)) {
				divisors.add(i);
			}
		}
		return divisors;
	}
	
	//Returns a string version of the question
	@Override
	public String toString() {
		return getNum1() + " � " + getNum2();
	}

}
